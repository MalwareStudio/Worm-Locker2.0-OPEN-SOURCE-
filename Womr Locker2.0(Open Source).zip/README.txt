WORM LOCKER2.0 |TROJAN-RANSOM.WIN32 (OPEN SOURCE)
******************************************************
If you damage your computer or another with this virus,
I am not responsible for your actions. This source code 
is for educational purposes only and does not encourage 
anyone to damage this malicious code. Dissemination of 
ransomware and other malicious software is against the 
law and is a criminal offense.
*******************************************************
Source code creator: Clutter Tech
Written by: C#
Date of creation: 12.12.2020
*******************************************************
Bugs: If a file such as an exe file is running on the 
desktop or in a downloaded file, the ransomware crashes
*******************************************************